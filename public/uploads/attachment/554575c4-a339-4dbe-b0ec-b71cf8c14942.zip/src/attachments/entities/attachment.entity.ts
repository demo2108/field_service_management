import { LocationMaster } from 'src/location_master/entities/location-master.entity';
import { User } from 'src/users/entities/user.entity';
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('attachments')
export class Attachment {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  work_order_id: number;

  @Column({ nullable: true })
  uploaded_by: number;

  @Column({ type: 'text' })
  file_url: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  file_type: string;

  @CreateDateColumn({ type: 'timestamp' })
  uploaded_at: Date;

  @Column({ type: 'text', nullable: true })
  remarks: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  document_name: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  document_number: string;

      @ManyToOne(() => LocationMaster, { nullable: true, onUpdate: 'CASCADE', onDelete: 'SET NULL' })
    @JoinColumn({ name: 'location_id' }) 
    location?: LocationMaster;

      @Column() // ✅ This is the missing piece if it's not working
  location_id: number;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;
  
    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
    
    @ManyToOne(() => User)
    @JoinColumn({ name: 'created_by' })
    creator: User;
  
    @Column({ nullable: true })
    updated_by: number;
    @ManyToOne(() => User)
    @JoinColumn({ name: 'updated_by' })
    updator: User;


    
}
