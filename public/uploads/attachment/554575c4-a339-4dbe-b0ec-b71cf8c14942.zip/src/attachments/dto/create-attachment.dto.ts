// // create-attachment.dto.ts
// import { Type } from 'class-transformer';
// import { IsString, IsOptional, IsNotEmpty, IsNumber, Min, IsInt } from 'class-validator';

// export class CreateAttachmentDto {
//   @IsOptional()
//   @IsString()
//   document_name?: string;

//   @IsOptional()
//   @IsString()
//   document_number?: string;

//   @IsOptional()
//   @IsString()
//   remarks?: string;

//   @IsOptional()
//   @IsString()
//   file_type?: string;

//   @IsOptional()
//   uploaded_by?: number;

//   @IsOptional()
//   work_order_id?: number;

//   @IsOptional()
//   @IsString()
//   file_url?: string; // will be set by controller
  
//     @IsNotEmpty({ message: 'location_id is required' })
//     @IsNumber()
//     @Type(() => Number)
//       @Min(1, { message: 'location_id must be greater than 0' })
//     location_id: number;


//       @IsInt()  
//         created_by: number;
        
//           @IsOptional()
//         updated_by: number;
    
//         @IsOptional()
//         @Type(() => Date)
//         updated_at?: Date;
// }
import { Type } from 'class-transformer';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  Min,
  IsInt,
} from 'class-validator';

export class CreateAttachmentDto {
  @IsOptional()
  @IsString()
  document_name?: string;

  @IsOptional()
  @IsString()
  document_number?: string;

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsNotEmpty({ message: 'file_type is required (e.g., image/png)' })
  @IsString()
  file_type: string;

  @IsOptional()
  uploaded_by?: number;

  @IsOptional()
  work_order_id?: number;

  @IsOptional()
  @IsString()
  file_url?: string;

  @IsNotEmpty({ message: 'base64_file is required' })
  @IsString()
  base64_file: string;

  @IsNotEmpty({ message: 'location_id is required' })
  @IsNumber()
  @Type(() => Number)
  @Min(1, { message: 'location_id must be greater than 0' })
  location_id: number;

  @IsInt({ message: 'created_by must be an integer' })
  created_by: number;

  @IsOptional()
  updated_by: number;

  @IsOptional()
  @Type(() => Date)
  updated_at?: Date;
}
