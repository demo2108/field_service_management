import { BadRequestException, Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, UploadedFile, UseInterceptors } from '@nestjs/common';
import { CreateAttachmentDto } from './dto/create-attachment.dto';
import { AttachmentsService } from './attachments.service';
import { UpdateAttachmentDto } from './dto/update-attachment.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid'


@Controller('attachments')
export class AttachmentsController {
      constructor(private readonly attachmentService: AttachmentsService) {}
    
@Post()
async uploadBase64File(@Body() body: any) {
  const { base64_file, file_type } = body;

  if (!base64_file || !file_type) {
    return { statusCode: 400, message: 'base64_file and file_type are required' };
  }

  try {
    // Extract extension from MIME type
    const ext = file_type.split('/')[1] || 'bin';

    // Generate unique filename
    const { v4: uuidv4 } = require('uuid');
    const fileName = `${uuidv4()}.${ext}`;

    // Define full path
    const filePath = path.join(__dirname, '..', '..', 'public', 'uploads', 'attachment', fileName);

    // Decode base64 and write to file
    const buffer = Buffer.from(base64_file, 'base64');

    // Check if base64 is valid
    if (!buffer || !buffer.length) {
      return { statusCode: 400, message: 'Invalid base64 data' };
    }

    fs.writeFileSync(filePath, buffer);

    // Build relative URL
    const file_url = `uploads/attachment/${fileName}`;

    // Save to DB
    return this.attachmentService.create({ ...body, file_url });
  } catch (err) {
    console.error('❌ File upload failed:', err);
    return {
      statusCode: 500,
      message: 'Failed to upload file',
    };
  }
}
//  @Post('upload')
//   @UseInterceptors(FileInterceptor('file', {
//     storage: diskStorage({
//       destination: './public/uploads/attachment',
//       filename: (req, file, cb) => {
//         const ext = path.extname(file.originalname);
//         cb(null, `${uuidv4()}${ext}`);
//       },
//     }),
//   }))
//   async uploadAttachment(
//     @UploadedFile() file: Express.Multer.File,
//     @Body() body: any
//   ) {
//     let file_url: string;
//     let file_type: string;

//     if (body.base64_file) {
//       const matches = body.base64_file.match(/^data:(.*);base64,(.*)$/);
//       if (!matches) throw new BadRequestException('Invalid base64 format.');

//       file_type = matches[1];
//       const ext = file_type.split('/')[1];
//       const buffer = Buffer.from(matches[2], 'base64');
//       const filename = `${uuidv4()}.${ext}`;
//       const savePath = path.join(__dirname, '..', '..', 'public', 'uploads', 'attachment', filename);

//       fs.writeFileSync(savePath, buffer);
//       file_url = `/uploads/attachment/${filename}`;
//     } else if (file) {
//       file_url = `/uploads/attachment/${file.filename}`;
//       file_type = file.mimetype;
//     } else {
//       throw new BadRequestException('Either base64 or file is required.');
//     }

//     const savedAttachment = await this.attachmentService.createAttachment({
//       ...body,
//       file_url,
//       file_type,
//     });

//     return {
//       statusCode: 201,
//       message: 'Attachment uploaded successfully',
//       data: savedAttachment,
//     };
//   }
@Put(':id')
async updateAttachment(
  @Param('id', ParseIntPipe) id: number,
  @Body() body: any
) {
  const { base64_file, file_type } = body;

  let file_url: string | undefined;

  if (base64_file) {
    // Validate presence of file_type
    if (!file_type || typeof file_type !== 'string') {
      return { statusCode: 400, message: 'file_type is required when base64_file is provided' };
    }

    // Decode base64 (no prefix expected)
    let buffer: Buffer;
    try {
      buffer = Buffer.from(base64_file, 'base64');
      if (!buffer || !buffer.length) {
        return { statusCode: 400, message: 'Invalid base64 data' };
      }
    } catch (err) {
      return { statusCode: 400, message: 'Failed to decode base64 data' };
    }

    // Extract extension and generate unique file name
    const ext = file_type.split('/')[1] || 'bin';
    const { v4: uuidv4 } = require('uuid');
    const fileName = `${uuidv4()}.${ext}`;
    const filePath = path.join(__dirname, '..', '..', 'public', 'uploads', 'attachment', fileName);

    fs.writeFileSync(filePath, buffer);
    file_url = `uploads/attachment/${fileName}`;
  }

  const updateData = {
    ...body,
    ...(file_url && { file_url }),
  };

  return this.attachmentService.updateAttachment(id, updateData);
}

  @Get('all')
async findAllAttachments() {
  return this.attachmentService.findAllAttachments();
}
@Delete(':id')
async deleteAttachment(@Param('id', ParseIntPipe) id: number) {
  return this.attachmentService.deleteAttachment(id);
}
@Post('search')
searchattechment(@Body() body: {
  Page: number;
  PageSize: number;
  StartDate?: string;
  EndDate?: string;
  Search?: string;
 // location_id?: number;
}) {
  return this.attachmentService.searchWithPagination(body);
}


}


