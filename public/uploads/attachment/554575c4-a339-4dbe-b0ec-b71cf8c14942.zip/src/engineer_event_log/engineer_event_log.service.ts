import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EventLog } from './entities/event_log.entity';
import { DeepPartial, Repository } from 'typeorm';
import { CreateEventLogDto } from './dto/create-event-log.dto';
import { WorkOrder } from 'src/work_orders/entities/work-order.entity';
import { ServiceRequest } from 'src/service_request/entities/service-request.entity';
import { UpdateExitTimeDto } from './dto/update-exit-time.dto';

@Injectable()
export class EngineerEventLogService {
   constructor(
    @InjectRepository(EventLog)
    private readonly eventLogRepo: Repository<EventLog>,

    @InjectRepository(WorkOrder)
    private readonly workOrderRepo: Repository<WorkOrder>,

    @InjectRepository(ServiceRequest)
    private readonly serviceRequestRepo: Repository<ServiceRequest>,
  ) {}

  private async validateWorkOrderAndRequest(dto: { work_order_id: number; service_request_id: number }) {
    const workOrder = await this.workOrderRepo.findOneBy({ id: dto.work_order_id });
    if (!workOrder) {
      throw new BadRequestException(`Work order ID ${dto.work_order_id} does not exist.`);
    }

    const serviceRequest = await this.serviceRequestRepo.findOneBy({ id: dto.service_request_id });
    if (!serviceRequest) {
      throw new BadRequestException(`Service request ID ${dto.service_request_id} does not exist.`);
    }
  }

//   async create(dto: CreateEventLogDto): Promise<EventLog> {
//     await this.validateWorkOrderAndRequest(dto); 
//     const eventLog = this.eventLogRepo.create(dto);
//     return await this.eventLogRepo.save(eventLog);
//   }


async create(dto: CreateEventLogDto): Promise<EventLog> {
  await this.validateWorkOrderAndRequest(dto);

  const now = new Date();

  const eventLog: DeepPartial<EventLog> = {
    ...dto,
    location_time: dto.location_time ?? now,
    entry_time: now,
    changed_at: now,
    event_name: dto.event_name ?? 'Work Order Entry',
    status: dto.status ?? 'Started',
    
  };

  return await this.eventLogRepo.save(eventLog);
}

async updateExitTime(id: number, exitTime: string): Promise<{ message: string }> {
  const log = await this.eventLogRepo.findOneBy({ id });
  if (!log) {
    throw new NotFoundException(`Event log with ID ${id} not found`);
  }

  log.extending_date = new Date(exitTime);
  await this.eventLogRepo.save(log);

  return { message: 'You are back from work order' };
}



  async findAll(): Promise<EventLog[]> {
    return this.eventLogRepo.find();
  }

  async findOne(id: number): Promise<EventLog> {
    const event = await this.eventLogRepo.findOneBy({ id });
    if (!event) {
      throw new BadRequestException(`EventLog with ID ${id} not found.`);
    }
    return event;
  }

  async remove(id: number): Promise<void> {
    const event = await this.findOne(id); // will throw if not found
    await this.eventLogRepo.remove(event);
  }
}
