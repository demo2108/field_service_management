import { Body, Controller, Get, NotFoundException, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { EngineerEventLogService } from './engineer_event_log.service';
import { CreateEventLogDto } from './dto/create-event-log.dto';
import { UpdateExitTimeDto } from './dto/update-exit-time.dto';

@Controller('engineer-event-log')
export class EngineerEventLogController {
      constructor(private readonly eventLogService: EngineerEventLogService) {}

  @Post()
  create(@Body() dto: CreateEventLogDto) {
    return this.eventLogService.create(dto);
  }

  @Get()
  findAll() {
    return this.eventLogService.findAll();
  }

@Put(':id/exit-time')
async updateExitTime(
  @Param('id', ParseIntPipe) id: number,
  @Body('exit_time') exitTime: string,
): Promise<{ message: string }> {
  return this.eventLogService.updateExitTime(id, exitTime);
}

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.eventLogService.findOne(+id);
  }
}
