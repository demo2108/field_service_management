// update-service-request.dto.ts
import { Type } from 'class-transformer';
import {
  IsOptional,
  IsInt,
  IsString,
  IsBoolean,
  IsDateString,
  IsArray,
  ArrayNotEmpty,
  IsNumber,
  IsNotEmpty,
  Min,
  MaxLength,
} from 'class-validator';

export class UpdateServiceRequestDto {
  @IsOptional()
  @IsInt()
  work_order_id?: number;

  // @IsOptional()
  // @IsInt()
  // service_name_id?: number;
  @IsNotEmpty()
  @IsInt({ message: 'app_dir_id must be an integer' })
  @Min(1, { message: 'app_dir_id must be greater than 0' })
  app_dir_id?: number;
// @IsOptional()
// @IsArray()
// @IsInt({ each: true })
// engineer_ids?: number[];
@IsOptional()
@IsArray()
@ArrayNotEmpty()
engineer_ids?: number[];


  // @IsOptional()
  // @IsInt()
  // created_by?: number;


  @IsInt()
  @IsNotEmpty({ message: 'Updated by is required' })
  updated_by: number;

  @IsOptional()
  @IsBoolean()
  acknowledged?: boolean;

  @IsOptional()
  @IsDateString()
  acknowledged_at?: string;

  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsString()
  unavailability_reason?: string;

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @IsBoolean()
  is_active?: boolean;

  @IsOptional()
  @IsString()
  priority?: string;

  @IsOptional()
  @IsInt()
  sequence?: number;

  @IsOptional()
  @IsString()
  customer_feedback?: string;

  @IsOptional()
  @IsString()
  customer_signature_path?: string;

  @IsOptional()
  @IsDateString()
  target_completion_date?: Date;

  @IsOptional()
  @IsDateString()
  starting_date?: Date;

  @IsNotEmpty({ message: 'location_id is required' })
  @IsNumber()
  @Type(() => Number)
  @Min(1, { message: 'location_id must be greater than 0' })
  location_id: number;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  service_request_num?: string;


    @IsOptional()
  @IsString()
  @MaxLength(50)
  progress?: string;
}
